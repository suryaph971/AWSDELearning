import json
import base64

word_dict={}
def lambda_handler(event, context):
    # TODO implement

    for record in event['Records']:
        payload = base64.b64decode(record['kinesis']['data']).decode('utf-8')
        print("Payload :: ",payload)
        #word_data = json.loads(payload)
        word_data = payload.split(' ')
        for word in word_data:
            if word in word_dict:
                word_dict[word] += 1
            else:
                word_dict[word] = 1
        print(word_dict)

    return {
        'statusCode': 200,
        'body': json.dumps('Hello from Lambda!')
    }
